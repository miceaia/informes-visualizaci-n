<?php
 
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://codeados.com/
 * @since      1.0.0
 *
 * @package    Informes
 * @subpackage Informes/admin/partials
 */ 

global $wpdb; 

$tab = 1;
if(!isset($_GET['tab'])){

}else{
	$tab = $_GET['tab'];
}

if($tab == 1){

    //GET USERS
    $args = array(  'orderby' => 'user_nicename',   'order'   => 'ASC'  );
    $users_ = get_users( $args );  
    $users = array();
    foreach($users_ as $u){  $users[$u->ID]=$u->display_name;  }
    //GET LESSONS
    $args = array('post_status'=>'publish',  'orderby' => 'post_title',     'order'   => 'ASC'  ,   'post_type'   => 'sfwd-courses' ,'numberposts'=>-1  );
    $courses_ = get_posts( $args );
    $courses = array();
    foreach($courses_ as $c){  $courses[$c->ID]=$c->post_title;  }

    //SI NO TIENE FILTROS, MOSTRAMOS NADA 
    $filter_flag_1 = false;
    $filter_flag_2 = false;
    if(isset($_POST['course']) && $_POST['course']!='0'){
        $filter_flag_1 = true;
    }
    if(isset($_POST['user_id']) && $_POST['user_id']!='0'){
        $filter_flag_2 = true;
    }
    if($filter_flag_1==false && $filter_flag_2 == false){
        $results = [];
    }else{  
        $args = array('orderby' => 'post_title', 	'order'   => 'ASC'  , 	'post_type'   => 'sfwd-lessons' ,'numberposts'=>-1	);
        $lessons_ = get_posts( $args );
        $lessons = array();
        $lessons_time = array();
        $lessons_course = array(); 
        foreach($lessons_ as $l){  
            $lessons[$l->ID]=$l->post_title; 
            $lessons_time[$l->ID]=$l->minutos_video;  
            $lessons_course[$l->course_id][]=$l->ID;
        }  
        $results = array();
        if(isset($_POST['form_submitted'])){
            $and_1 = ''; 
            $_POST['user_id'] = intval($_POST['user_id']);
            $_POST['course'] = intval($_POST['course']);
            if($_POST['user_id']>0){
            	$and_1 = " user_id=".$_POST['user_id']." ";
            }
            $and_2 = '';
            if($_POST['course']>0 && $_POST['user_id']>0){
            	$and_2 = ' AND ';   
            }
            if($_POST['course']>0){
                $and_2 .= "  lesson_id IN(".implode(', ',$lessons_course[$_POST['course']]).")";
            }
            $query_ = "SELECT * FROM ".$wpdb->prefix."lessons_views WHERE $and_1  $and_2  ORDER BY id_lesson_view DESC";  
        	$results = $wpdb->get_results ( $query_  ); 
        }else{
        	$results = $wpdb->get_results ( "SELECT * FROM ".$wpdb->prefix."lessons_views ORDER BY id_lesson_view DESC LIMIT 30" );  
        }
    }
}
if($tab == 2){
	 
}
if($tab == 3){
	 
}
	
if($tab == 4){
	 
}
if($tab == 5){

	 
}
?>
<div class="wrap" id="informe_0" style="margin-top: 00px;">
	<!--<a href="/wp-admin/admin.php?page=informes&tab=1" style=" text-align: center;   padding:3px 10px;    font-size: 15px;"  class="button button-primary button-block">Visualizaciones</a>
	
	<a href="/wp-admin/admin.php?page=informes&tab=2" style=" text-align: center;   padding:3px 10px;    font-size: 15px;"  class="button button-primary button-block">ER/RGPD y Clientes</a>
	<a href="/wp-admin/admin.php?page=informes&tab=3" style=" text-align: center;   padding:3px 10px;    font-size: 15px;"  class="button button-primary button-block">Recuento Usuario/Modalidad</a>
	<a href="/wp-admin/admin.php?page=informes&tab=4" style=" text-align: center;   padding:3px 10px;    font-size: 15px;"  class="button button-primary button-block">Recuento Evento/Usuarios</a>

	<a href="/wp-admin/admin.php?page=informes&tab=5" style=" text-align: center;   padding:3px 10px;    font-size: 15px;"  class="button button-secondary button-block">Comparativa año</a>-->
</div> 
<?php if($tab == 1){ ?>
<div class="wrap" id="informe_1">
	<h1 style="margin-top: 20px;">Visualizaciones</h1>  
	<form method="post"   novalidate="novalidate">
		<input type="hidden" name="form_submitted" value="1">
		<table class="form-table informes_filter" role="presentation" style="    border: 2px solid;">
		<tbody>
			<tr>
			<td  style="padding-top: 0; padding-bottom: 0;">
			<label for="for">Curso</label>
			<select name="course" id="course">
				<option value="0">Todos</option> 
                <?php
                 
                	foreach ( $courses as $course_id => $course ) {
                        $selected = '';
                        if(isset($_POST['course']) && $course_id==$_POST['course']){
                        	$selected = ' selected ';
                        }
                        echo '<option value="'.$course_id.'" '.$selected.'>'.esc_html($course).'</option>';   
                    }  
                ?>
			</select>
		</td>
			<td colspan="2"  style="padding-top: 0; padding-bottom: 0;">
			<label for="for">Usuario</label>
			<select name="user_id" id="user_id">
				<option value="0">Todos</option> 
                <?php
                	foreach ( $users as $user_id => $user ) { 
                        $selected = '';
                        if(isset($_POST['user_id']) && $user_id==$_POST['user_id']){
                        	$selected = ' selected ';
                        }
                        echo '<option value="'.$user_id.'" '.$selected.'>'.esc_html( $user ).'</option>';   
                    }  
                ?>
			</select>
		</td>   
			<td style="padding-top: 0; "><label for="">&nbsp;</label><input style="    padding: 3px;    width: 100%;    font-size: 17px;" type="submit" name="submit" id="submit" class="button button-primary button-block" value="Aceptar"></td>
			<td style="padding-top: 0; "><label for="">&nbsp;</label><a style="    padding: 3px;    width: 100%;    font-size: 17px; background: #000;     text-align: center;    border: 1px solid #000;" href=""  class="button button-primary button-block" value="">Reset</a></td>
		</tr> 
		</tbody></table>
	</form>  
	<table id="table_id" class="display">
	    <thead>
	        <tr>
				<th>Usuario</th>
                <th>Curso</th>
                <th>Lección</th>
                <th>Visualizado</th>
                <th>Acción</th>
	        </tr>
	    </thead>
	    <tbody> 
              <?php 
              	foreach ($results as $lv ){ 
	   		 		echo '<tr id="item_view_'.$lv->user_id.'_'.$lv->lesson_id.'">';
                    echo '<td>'.$users[$lv->user_id].'</td>';
                    echo '<td class="text-center">'.$courses[get_post_meta($lv->lesson_id,'course_id',true)].'</td>';
                    echo '<td class="text-center">'.$lessons[$lv->lesson_id].'</td>';
                    echo '<td class="text-center">'.round($lv->seconds/60).'/'.$lessons_time[$lv->lesson_id].'</td>';
                    echo '<td><a class="button button-primary button-block" style="      padding: 0;    width: 100%;    font-size: 15px;
    background: #a90000;    text-align: center;    border: 1px solid #a90000;    line-height: 26px;" href="javascript:void(0)" onclick="deleteView('.$lv->user_id.','.$lv->lesson_id.')">Borrar</a</td>';
                    echo '</tr>';
                    
				}  
              ?>
	    </tbody>
	</table>	
</div>
<?php } ?>

<?php if($tab == 2){ ?>

<?php } ?>

<?php if($tab == 3){ ?>

<?php } ?>

<?php if($tab == 4){ ?>

<?php } ?>


<?php if($tab == 5){ ?>

<?php } ?>



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> 
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"> 
 <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
 <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
 <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
 <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
 <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
 <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
    
<script>
jQuery(document).ready( function () {
   jQuery('#table_id').DataTable({
        dom: 'Bfrtip',
        "pageLength": -1,
        buttons: [
            'copy', 'excel', 'print',
			{
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'A4', customize : function(doc) {doc.pageMargins = [10, 10, 10,10 ]; }
            }
        ]
   });
});
function deleteView(user_id,lesson_id){  
    var data = {
        action: 'delete_view',
        user_id: user_id  ,
        lesson_id: lesson_id  
    };    
    jQuery('#item_view_'+user_id+'_'+lesson_id).hide(0);
    jQuery.ajax({
            url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
            data:data,
            success:function(data) {  
            },
            error: function(errorThrown){
                console.log(errorThrown);
            }
        }); 

}
</script>
<style>
.text-center { text-align:center; }   
</style>