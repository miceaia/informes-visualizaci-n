<?php

/**
 * Fired during plugin activation
 *
 * @link       https://codeados.com/
 * @since      1.0.0
 *
 * @package    Informes
 * @subpackage Informes/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Informes
 * @subpackage Informes/includes
 * @author     CODEADOS <propuestas@codeados.com>
 */
class Informes_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
